/**
 * [中央事件总线]
 */
import Vue from 'vue'
export default new Vue()